# Hack-With-Gujarat

# E-Collector

Step 1 : Download the zip file of the project and extract <br>
Step 2 : Download yolo weights and place in same directory (LINK : https://tinyurl.com/yolo-weights ) <br>
Step 2 : Open VS code or your preferred code editor and open up its terminal (VS CODE : cntrl + ~)<br>
Step 3 : Run app.py file <br>
Step 4 : Open auth.html in live server and replicate the page in incognito tab<br>
Step 5 : Use `Vikraman@gmail.com` & `123456` (Username & password) for the User - End <br>
Step 6 : Use `tech@gmail.com` & `123456` (Username & password) for the Technician End<br>
Step 7 : Use `Partner1@gmail.com` & `123456` (Username & password) for the Partner End<br>
Step 8 : Use `admin@gmail.com` & `123456` (Username & password) for the Admin End<br>
Step 9 : Use the features in the app & refer to the video attatched in the submission form .<br><br><br>


Thank you
